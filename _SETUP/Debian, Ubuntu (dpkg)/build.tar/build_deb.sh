#!/bin/bash
p7zip
if [ $? -eq 127 ]; then
	echo "p7zip is required. Run apt-get install p7zip"
	exit 1
fi
wget http://downloads.fdossena.com/geth.php?r=stickynotes-bin -O notebot.7z
if [ $? -ne 0 ]; then
	echo "Download failed"
	exit 2
fi
p7zip -d notebot.7z
rm -f *.txt
rm -f *.md
chmod 755 *.jar
mv *.jar notebot/usr/share/notebot/
dpkg -b notebot/ notebot.deb
